import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import type { SMKAccount } from "@/types/interfaces/accountAdmin";

export async function getSMKAccounts(): Promise<SMKAccount[]> {
    const session = await getServerSession(authOptions);

    if (!session || session.user.role !== "SuperAdmin") {
        redirect("/auth/login");
    }

    const users = await prisma.user.findMany({
        where: {
            role: { in: ["User", "AdminSMK"] },
        },
        orderBy: { createdAt: "desc" },
        include: {
            smk: true,
            alamat: {
                orderBy: { isUtama: "desc" }, 
                take: 1,
            },
        },
    });

    const accounts: SMKAccount[] = users.map((u) => {
        const alamatUtama = u.alamat[0];
        const alamatText = u.smk?.alamat
            ?? (alamatUtama
                ? `${alamatUtama.alamat_lengkap}, ${alamatUtama.kecamatan}, ${alamatUtama.kota}, ${alamatUtama.provinsi}`
                : null);

        return {
            user_id: u.user_id,
            name: u.name,
            email: u.email,
            phone: u.phone ?? null,
            img: u.img ?? null,
            role: u.role,
            isActive: u.isActive,
            smk_id: u.smk?.smk_id ?? null,
            kepala_sekolah: u.smk?.kepala_sekolah ?? null,
            alamat: alamatText,
            kota: u.smk?.kota ?? alamatUtama?.kota ?? null,
            provinsi: u.smk?.provinsi ?? alamatUtama?.provinsi ?? null,
        };
    });

    return accounts;
}