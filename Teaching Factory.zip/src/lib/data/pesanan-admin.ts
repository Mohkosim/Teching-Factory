import "server-only";
import { prisma } from "@/lib/prisma";
import type { OrderRow } from "@/types/interfaces/pesananAdmin";

export async function getPesananByJurusan(jurusan_id: string): Promise<OrderRow[]> {
    const orders = await prisma.order.findMany({
        where: {
            kode_invoice: { not: null },
            OR: [
                { seller_jurusan_id: jurusan_id },
                {
                    seller_jurusan_id: null,
                    orderDetail: {
                        some: { produk: { jurusan_id } },
                        none: { produk: { jurusan_id: { not: jurusan_id } } },
                    },
                },
            ],
        },
        include: {
            user: true,
            pengiriman: true,
            transaksi: {
                where: { jenis_transaksi: "Pemasukan", status_settlement: "Selesai" },
                select: { nominal: true },
            },
            refundRequest: { include: { bukti: true } },
            orderDetail: {
                where: { produk: { jurusan_id } },
                include: {
                    produk: {
                        include: {
                            foto: { take: 1, orderBy: { createdAt: "asc" } },
                            jasa: true,
                            barang: true,
                        },
                    },
                    kombinasi: { include: { opsi: { include: { opsi: true } } } },
                },
            },
        },
        orderBy: { createdAt: "desc" },
    });

    return orders.map((order) => {
        const items = order.orderDetail.map((detail) => ({
            order_detail_id: detail.order_detail_id,
            produk_id: detail.produk_id,
            nama_produk: detail.produk.nama_produk,
            foto: detail.produk.foto[0]?.url ?? null,
            jumlah: detail.jumlah,
            harga_satuan: detail.harga_satuan,
            subtotal: detail.subtotal,
            varianLabel: detail.kombinasi
                ? detail.kombinasi.opsi.map((ko) => ko.opsi.nama).join(", ")
                : undefined,
        }));
        const firstProduk = order.orderDetail[0]?.produk;
        const kategori: "Produk" | "Jasa" =
            firstProduk && firstProduk.jasa.length > 0 ? "Jasa" : "Produk";


        return {
            order_id: order.order_id,
            kode_invoice: order.kode_invoice,
            orderDate: order.createdAt,
            kategori,
            items,
            buyerName: order.user.name,
            buyerPhone: order.user.phone ?? "-",
            buyerEmail: order.user.email,
            buyerAddress: order.pengiriman?.alamat ?? "-",
            totalHarga: order.total_harga,
            ongkir: order.pengiriman?.ongkir ?? 0,
            totalDibayar: order.transaksi.reduce((sum, t) => sum + t.nominal, 0),
            statusPembayaran: order.status_pembayaran,
            statusPengiriman: order.status_order,
            kurir: order.pengiriman?.kurir ?? "-",
            nomorResi: (order.pengiriman as { nomor_resi?: string } | null)?.nomor_resi ?? null,
            estimasi: order.pengiriman?.estimasi_tiba ?? null,
            refund: order.refundRequest
                ? {
                    id: order.refundRequest.refund_id,
                    status: order.refundRequest.status,
                    alasan: order.refundRequest.alasan,
                    deskripsi: order.refundRequest.deskripsi,
                    catatanAdmin: order.refundRequest.catatanAdmin,
                    bukti: order.refundRequest.bukti.map((b) => ({
                        id: b.bukti_id,
                        url: b.url,
                        tipe: b.tipe,
                    })),
                }
                : null,
        };
    });
}