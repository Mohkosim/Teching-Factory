"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import Swal from "sweetalert2";
import { tampilkanLoading } from "@/lib/utils/alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import AuthTabs from "@/components/auth/AuthTabs";
import FormField from "@/components/auth/FormField";
import PasswordInput from "@/components/auth/PasswordInput";
import { registerSchema, type RegisterSchema } from "@/lib/validations/auth";
import Image from "next/image";

export default function RegisterForm() {
    const router = useRouter();

    const {
        register,
        handleSubmit,
        formState: { errors, isSubmitting },
    } = useForm<RegisterSchema>({
        resolver: zodResolver(registerSchema),
    });

    const onSubmit = async (data: RegisterSchema) => {
        tampilkanLoading("Membuat akun...");
        try {
            const res = await fetch("/api/auth/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data),
            });

            const json = await res.json();
            Swal.close();

            if (!res.ok && !json.pendingVerification) {
                throw new Error(json.message ?? "Terjadi kesalahan");
            }

            const emailBelumTerkirim = !res.ok;
            const pergiKeVerifikasi = () => {
                router.push(`/auth/verify-otp?email=${encodeURIComponent(data.email)}`);
            };

            if (emailBelumTerkirim) {
                toast.warning("Akun dibuat, tapi email belum terkirim", {
                    description: json.message,
                    duration: 2500,
                    onAutoClose: pergiKeVerifikasi,
                });
            } else {
                toast.success("Akun berhasil dibuat!", {
                    description: "Silakan cek email Anda untuk kode verifikasi (cek juga folder Spam).",
                    duration: 1500,
                    onAutoClose: pergiKeVerifikasi,
                });
            }
        } catch (err) {
            Swal.close();
            const errormassage = err instanceof Error ? err.message : "Terjadi kesalahan";
            toast.error("Gagal membuat akun", {
                description: errormassage,
            });
        }
    };

    return (
        <>
            <div className="text-center w-full">
                <span className="text-3xl font-black text-gray-900 tracking-tight block">
                    <Image
                        src="/img/LogoTefa.png"
                        alt="Logo Tefa"
                        width={150}
                        height={80}
                        className="object-contain w-auto h-auto mx-auto block"
                        priority
                    />
                </span>
            </div>

            <AuthTabs />

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5" noValidate>

                <FormField label="Nama Pengguna" htmlFor="username" error={errors.username?.message}>
                    <Input
                        id="username"
                        type="text"
                        placeholder="Masukkan Nama Pengguna"
                        className={`bg-sky-50 border-0 rounded-xl h-12 text-sm placeholder:text-gray-400 focus-visible:ring-sky-400 ${errors.username ? "ring-1 ring-red-400 focus-visible:ring-red-400" : ""
                            }`}
                        {...register("username")}
                    />
                </FormField>

                <FormField label="E-mail" htmlFor="email" error={errors.email?.message}>
                    <Input
                        id="email"
                        type="email"
                        placeholder="Masukkan E-mail"
                        className={`bg-sky-50 border-0 rounded-xl h-12 text-sm placeholder:text-gray-400 focus-visible:ring-sky-400 ${errors.email ? "ring-1 ring-red-400 focus-visible:ring-red-400" : ""
                            }`}
                        {...register("email")}
                    />
                </FormField>

                <FormField label="Kata Sandi" htmlFor="password" error={errors.password?.message}>
                    <PasswordInput
                        id="password"
                        hasError={!!errors.password}
                        {...register("password")}
                    />
                </FormField>

                <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full h-12 rounded-xl bg-sky-400 hover:bg-sky-500 text-white font-bold text-sm shadow-sm transition-colors duration-200 mt-2 disabled:opacity-60"
                >
                    {isSubmitting ? "Membuat akun..." : "Buat Akun"}
                </Button>

            </form>

            <p className="text-center text-sm text-gray-500 mt-4">
                Daftar sebagai SMK / Mitra{" "}
                <Link href="/auth/register/smk" className="font-semibold text-sky-500 hover:underline">
                    Daftar Admin
                </Link>
            </p>
        </>
    );
}